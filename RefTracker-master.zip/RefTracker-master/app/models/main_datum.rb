class MainDatum < ApplicationRecord
end
