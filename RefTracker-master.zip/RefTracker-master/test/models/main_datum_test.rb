require 'test_helper'

class MainDatumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
